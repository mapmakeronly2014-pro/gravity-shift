plugins {
    id("com.android.application")
}

android {
    namespace = "com.omarsaudi.stickersheet"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.omarsaudi.stickersheet"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "2.1"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
