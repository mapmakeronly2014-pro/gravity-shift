package com.omarsaudi.stickersheet;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * Sticker Sheet Maker for Android: the same app as the HTML file, running
 * inside a WebView, with Android's own print screen and image picker.
 */
public class MainActivity extends Activity {

    private static final int PICK_IMAGE = 41;
    private WebView web;
    private ValueCallback<Uri[]> pendingPick;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setTextZoom(100);

        web.addJavascriptInterface(new Bridge(), "AndroidApp");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();
                if ("file".equals(url.getScheme())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, url));
                } catch (ActivityNotFoundException ignored) {
                }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (pendingPick != null) pendingPick.onReceiveValue(null);
                pendingPick = callback;
                Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType("image/*");
                try {
                    startActivityForResult(Intent.createChooser(pick, "Choose an image"), PICK_IMAGE);
                } catch (ActivityNotFoundException e) {
                    pendingPick = null;
                    return false;
                }
                return true;
            }
        });

        if (saved != null) web.restoreState(saved);
        else web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && pendingPick != null) {
            pendingPick.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            pendingPick = null;
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    protected void onPause() {
        // The app saves its settings when the page closes; do the same
        // whenever Android sends the app to the background.
        web.evaluateJavascript("window.dispatchEvent(new Event('beforeunload'))", null);
        super.onPause();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    /** Called from the page: window.AndroidApp.print(name, widthMm, heightMm). */
    private class Bridge {
        @JavascriptInterface
        public void print(final String name, final double widthMm, final double heightMm) {
            runOnUiThread(() -> startPrint(name, widthMm, heightMm));
        }
    }

    private void startPrint(String name, double widthMm, double heightMm) {
        PrintManager manager = (PrintManager) getSystemService(PRINT_SERVICE);
        final PrintDocumentAdapter inner = web.createPrintDocumentAdapter(name);

        // The WebView's own adapter, plus a note to the page when the print
        // screen closes so it can put the preview back.
        PrintDocumentAdapter adapter = new PrintDocumentAdapter() {
            @Override
            public void onStart() {
                inner.onStart();
            }

            @Override
            public void onLayout(PrintAttributes oldAttributes, PrintAttributes newAttributes,
                                 CancellationSignal cancel, LayoutResultCallback callback, Bundle extras) {
                inner.onLayout(oldAttributes, newAttributes, cancel, callback, extras);
            }

            @Override
            public void onWrite(PageRange[] pages, ParcelFileDescriptor destination,
                                CancellationSignal cancel, WriteResultCallback callback) {
                inner.onWrite(pages, destination, cancel, callback);
            }

            @Override
            public void onFinish() {
                inner.onFinish();
                printDone();
            }
        };

        PrintAttributes attributes = new PrintAttributes.Builder()
                .setMediaSize(mediaFor(widthMm, heightMm))
                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                .build();
        try {
            manager.print(name, adapter, attributes);
        } catch (RuntimeException e) {
            printDone();
        }
    }

    private void printDone() {
        web.evaluateJavascript("window.__printDone && window.__printDone()", null);
    }

    private static boolean near(double a, double b) {
        return Math.abs(a - b) < 0.6;
    }

    /** Android's matching paper size, or a made-up one for unusual paper. */
    private static PrintAttributes.MediaSize mediaFor(double w, double h) {
        if (near(w, 210) && near(h, 297)) return PrintAttributes.MediaSize.ISO_A4;
        if (near(w, 148) && near(h, 210)) return PrintAttributes.MediaSize.ISO_A5;
        if (near(w, 297) && near(h, 420)) return PrintAttributes.MediaSize.ISO_A3;
        if (near(w, 105) && near(h, 148)) return PrintAttributes.MediaSize.ISO_A6;
        if (near(w, 176) && near(h, 250)) return PrintAttributes.MediaSize.ISO_B5;
        if (near(w, 215.9) && near(h, 279.4)) return PrintAttributes.MediaSize.NA_LETTER;
        if (near(w, 215.9) && near(h, 355.6)) return PrintAttributes.MediaSize.NA_LEGAL;
        if (near(w, 279.4) && near(h, 431.8)) return PrintAttributes.MediaSize.NA_TABLOID;
        int wMils = (int) Math.round(w / 25.4 * 1000);
        int hMils = (int) Math.round(h / 25.4 * 1000);
        return new PrintAttributes.MediaSize("STICKER_" + wMils + "x" + hMils, "Sticker paper", wMils, hMils);
    }
}
