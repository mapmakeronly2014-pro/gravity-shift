# Sticker Sheet Maker (Android)

GitHub builds the APK for you.

1. Upload everything in this folder to a GitHub repository, including the `.github` folder.
2. Open the **Actions** tab and wait for "Build APK" to get a green tick (about 5 minutes).
3. Open that run, scroll to **Artifacts**, download **Sticker-Sheet-Maker-APK** and unzip it.
4. Put `Sticker-Sheet-Maker.apk` on your phone and tap it to install.

To update the app later, replace `app/src/main/assets/index.html` with the new
Sticker Sheet Maker HTML file. GitHub builds a new APK by itself.
